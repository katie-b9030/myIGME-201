﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiskRank : MonoBehaviour
{
    public int rank = 3;
}
